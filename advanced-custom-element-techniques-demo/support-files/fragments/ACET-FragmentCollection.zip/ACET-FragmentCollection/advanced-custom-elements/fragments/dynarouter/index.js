import "liferay-react-router-test"
