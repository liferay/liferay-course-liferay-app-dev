import "liferay-tanstack-router-test"
