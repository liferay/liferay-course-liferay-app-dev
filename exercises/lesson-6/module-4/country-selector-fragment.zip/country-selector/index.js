const inputElement = document.getElementById(`${fragmentNamespace}-select-input`);
if (layoutMode === 'edit') {
	inputElement.setAttribute('disabled', true);
}