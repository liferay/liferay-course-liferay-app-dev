// src/index.js
import React6 from "react";
import { createRoot } from "react-dom/client";

// src/common/components/Comic.js
import React from "react";

// src/common/services/liferay/liferay.js
var Liferay = window.Liferay || {
  OAuth2: {
    getAuthorizeURL: () => "",
    getBuiltInRedirectURL: () => "",
    getIntrospectURL: () => "",
    getTokenURL: () => "",
    getUserAgentApplication: (_serviceName) => {
    }
  },
  OAuth2Client: {
    FromParameters: (_options) => {
      return {};
    },
    FromUserAgentApplication: (_userAgentApplicationId) => {
      return {};
    },
    fetch: (_url, _options = {}) => {
    }
  },
  ThemeDisplay: {
    getCompanyGroupId: () => 0,
    getScopeGroupId: () => 0,
    getSiteGroupId: () => 0,
    isSignedIn: () => {
      return false;
    }
  },
  authToken: ""
};

// src/common/components/Comic.js
var oAuth2Client;
try {
  oAuth2Client = Liferay.OAuth2Client.FromUserAgentApplication(
    "liferay-sample-etc-node-oauth-application-user-agent"
  );
} catch (error) {
  console.error(error);
}

// src/common/components/DadJoke.js
import React2 from "react";
var oAuth2Client2;
try {
  oAuth2Client2 = Liferay.OAuth2Client.FromUserAgentApplication(
    "liferay-sample-etc-spring-boot-oauth-application-user-agent"
  );
} catch (error) {
  console.error(error);
}
function DadJoke() {
  const [joke, setJoke] = React2.useState(null);
  React2.useEffect(() => {
    oAuth2Client2?.fetch("/dad/joke").then((response) => response.text()).then((joke2) => {
      setJoke(joke2);
    }).catch((error) => console.log(error));
  }, []);
  if (!joke) {
    return /* @__PURE__ */ React2.createElement("div", null, "Loading...");
  }
  return /* @__PURE__ */ React2.createElement("div", null, joke);
}
var DadJoke_default = DadJoke;

// src/common/services/liferay/api.js
var baseFetch = async (url, options = {}) => {
  return fetch(window.location.origin + "/" + url, {
    headers: {
      "Content-Type": "application/json",
      "x-csrf-token": Liferay.authToken
    },
    ...options
  });
};
var api_default = baseFetch;

// src/routes/hello-bar/pages/HelloBar.js
import React3 from "react";
var HelloBar = () => /* @__PURE__ */ React3.createElement("div", { className: "hello-bar" }, /* @__PURE__ */ React3.createElement("h1", null, "Hello Bar"));
var HelloBar_default = HelloBar;

// src/routes/hello-foo/pages/HelloFoo.js
import React4 from "react";
var HelloFoo = () => /* @__PURE__ */ React4.createElement("div", { className: "hello-foo" }, /* @__PURE__ */ React4.createElement("h1", null, "Hello Foo"));
var HelloFoo_default = HelloFoo;

// src/routes/hello-world/pages/HelloWorld.js
import React5 from "react";
var HelloWorld = () => /* @__PURE__ */ React5.createElement("div", { className: "hello-world" }, /* @__PURE__ */ React5.createElement("h1", null, "Hello ", /* @__PURE__ */ React5.createElement("span", { className: "hello-world-name" }, "World")));
var HelloWorld_default = HelloWorld;

// src/index.js
var App = ({ route }) => {
  if (route === "hello-bar") {
    return /* @__PURE__ */ React6.createElement(HelloBar_default, null);
  }
  if (route === "hello-foo") {
    return /* @__PURE__ */ React6.createElement(HelloFoo_default, null);
  }
  return /* @__PURE__ */ React6.createElement("div", null, /* @__PURE__ */ React6.createElement(HelloWorld_default, null), Liferay.ThemeDisplay.isSignedIn() && /* @__PURE__ */ React6.createElement("div", null, /* @__PURE__ */ React6.createElement("h3", null, "This is your Spring Boot Application calling the Dad Joke api"), /* @__PURE__ */ React6.createElement("hr", null), /* @__PURE__ */ React6.createElement(DadJoke_default, null)));
};
var WebComponent = class extends HTMLElement {
  connectedCallback() {
    this.root = createRoot(this);
    this.root.render(/* @__PURE__ */ React6.createElement(App, { route: this.getAttribute("route") }), this);
    if (Liferay.ThemeDisplay.isSignedIn()) {
      api_default("o/headless-admin-user/v1.0/my-user-account").then((response) => response.json()).then((response) => {
        if (response.givenName) {
          const nameElements = document.getElementsByClassName("hello-world-name");
          if (nameElements.length) {
            nameElements[0].innerHTML = response.givenName;
          }
        }
      }).catch((error) => {
        console.log(error);
      });
    }
  }
  disconnectedCallback() {
    this.root.unmount();
    delete this.root;
  }
};
var ELEMENT_ID = "liferay-sample-custom-element-2";
if (!customElements.get(ELEMENT_ID)) {
  customElements.define(ELEMENT_ID, WebComponent);
}
