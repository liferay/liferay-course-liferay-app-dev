async function renderTickets() {
    try {
        // Fetch tickets with custom headers
        const response = await fetch('/o/c/tickets', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'x-csrf-token': Liferay.authToken
            }
        });
        
        const ticketData = await response.json();
        const container = document.getElementById('ticket-container');
        container.innerHTML = ''; // Clear existing content

        if (ticketData.items && ticketData.items.length) {
            ticketData.items.forEach(ticket => {
                const ticketRow = document.createElement('div');
                ticketRow.className = 'ticket-row';
                ticketRow.innerHTML = `
                    <div>${ticket.id}</div>
                    <div>${ticket.subject}</div>
                    <div>${ticket.creator.name}</div>
                    <div>${ticket.ticketStatus.name}</div>
                `;
                container.appendChild(ticketRow);
            });
        } else {
            container.innerHTML = '<p>No tickets found</p>';
        }
    } catch (error) {
        console.error('Failed to fetch tickets:', error);
        document.getElementById('ticket-container').innerHTML = 
            '<p>Error loading tickets</p>';
    }
}

// Initial load
renderTickets();
setInterval(renderTickets, 10000);

